document.addEventListener('DOMContentLoaded', function () {
    // Tour data for 13 tours
    const toursData = [
        { title: 'Tour 1', description: 'Explore the beautiful beaches.', image: 'tour1.jpg' },
        { title: 'Tour 2', description: 'Discover the breathtaking mountains.', image: 'tour2.jpg' },
        { title: 'Tour 3', description: 'Experience the vibrant city life.', image: 'tour3.jpg' },
        { title: 'Tour 4', description: 'Journey through ancient ruins.', image: 'tour4.jpg' },
        { title: 'Tour 5', description: 'Safari adventure in the wild.', image: 'tour5.jpg' },
        { title: 'Tour 6', description: 'Relax at luxury resorts.', image: 'tour6.jpg' },
        { title: 'Tour 7', description: 'Hike in picturesque landscapes.', image: 'tour7.jpg' },
        { title: 'Tour 8', description: 'Cruise along stunning coastlines.', image: 'tour8.jpg' },
        { title: 'Tour 9', description: 'Immerse in cultural festivals.', image: 'tour9.jpg' },
        { title: 'Tour 10', description: 'Explore hidden gems.', image: 'tour10.jpg' },
        { title: 'Tour 11', description: 'Skiing in snow-covered mountains.', image: 'tour11.jpg' },
        { title: 'Tour 12', description: 'Taste local culinary delights.', image: 'tour12.jpg' },
        { title: 'Tour 13', description: 'Adventures on the high seas.', image: 'tour13.jpg' },
    ];

    const toursContainer = document.getElementById('tours');

    // Populate tour cards
    toursData.forEach(tour => {
        const card = document.createElement('div');
        card.classList.add('tour-card');

        const image = document.createElement('img');
        image.src = tour.image;
        image.alt = tour.title;

        const title = document.createElement('div');
        title.classList.add('tour-title');
        title.textContent = tour.title;

        const description = document.createElement('div');
        description.classList.add('tour-description');
        description.textContent = tour.description;

        card.appendChild(image);
        card.appendChild(title);
        card.appendChild(description);

        toursContainer.appendChild(card);
    });
});
