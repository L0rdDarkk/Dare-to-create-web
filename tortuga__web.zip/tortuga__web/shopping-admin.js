// Sample tour data (replace this with your actual tour data)
const tours = [
    { id: 1, title: "Tour 1", description: "Description for Tour 1" },
    { id: 2, title: "Tour 2", description: "Description for Tour 2" },
    // Add more tour objects as needed
  ];
  
  const searchInput = document.getElementById("search-input");
  const searchIcon = document.getElementById("search-icon");
  const tourList = document.getElementById("tour-list");
  
  function renderTours(filteredTours) {
    tourList.innerHTML = "";
    filteredTours.forEach(tour => {
      const tourCard = document.createElement("div");
      tourCard.className = "tour-card";
      tourCard.innerHTML = `
        <h2>${tour.title}</h2>
        <p>${tour.description}</p>
      `;
      tourList.appendChild(tourCard);
    });
  }
  
  function handleSearch() {
    const searchTerm = searchInput.value.toLowerCase();
    const filteredTours = tours.filter(tour => tour.title.toLowerCase().includes(searchTerm));
    renderTours(filteredTours);
  }
  
  searchIcon.addEventListener("click", handleSearch);
  searchInput.addEventListener("input", handleSearch);
  