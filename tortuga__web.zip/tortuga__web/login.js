let users = {
  admin: { username: 'admin', password: 'admin', dashboard: 'admin-dashboard.html' },
  user: { username: 'test', password: 'test', dashboard: 'user-dashboard.html' }
 };
 
 document.getElementById('login-form').addEventListener('submit', function(event) {
  event.preventDefault();
  const username = document.getElementById('username').value;
  const password = document.getElementById('password').value;
   
  for (let user in users) {
     if (users[user].username === username && users[user].password === password) {
       // Redirect to the user's dashboard page
       window.location.href = users[user].dashboard;
       return;
     }
  }
   
  alert('Invalid username or password. Please try again.');
 });